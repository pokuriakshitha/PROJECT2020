<?php
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	
	// Database connection
	$conn = new mysqli('127.0.0.1','root','','project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("INSERT INTO contactform(`name`, `phone`, `email`,`subject`,`message`) 
		VALUES ('$name', '$phone', '$email','$subject','$message')");
		$execval = $stmt->execute();
		echo $execval;
		$stmt->close();
        $conn->close();
        header("Location:http://localhost/project/contactus.php");
	}
?>