<?php
session_start();
$mysqli = new mysqli('127.0.0.1', 'root', '', 'project');

if(isset($_POST['submit']))
{
$username = trim($_POST['roll']);
$password = trim($_POST['password']);
$query = "SELECT * FROM admissions WHERE studentemailid='$username' 
AND parentmobile = '$password'";

$result = mysqli_query($mysqli,$query)or die(mysqli_error());
$num_row = mysqli_num_rows($result);
$row=mysqli_fetch_array($result);
if( $num_row ==1 )
     {
  header("Location: http://localhost/project/academics.php");
  }
  else
     {
 echo 'oops  can not do it';
  }
 }
?>