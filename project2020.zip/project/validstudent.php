<?php
session_start();
$name_pattern = '/^[a-zA-Z ]*$/';
if(!empty( $_POST['roll'])&&!empty( $_POST['password']))
    {
        $_SESSION['roll']=$student_name = $_POST['roll'];
        $_SESSION['password']=$student_pass = $_POST['password'];
        echo $student_name;
        echo "<br>";
        echo $student_pass;
        $con = mysqli_connect('localhost','root');
            if($con)
             {
             mysqli_select_db($con,'project');
         
            $query = "SELECT * FROM admissions WHERE stdudentmailid=$student_name AND parentmobile=$student_pass";
           
            $result =  mysqli_query($con,$query);
            while($row = mysqli_fetch_assoc($result))
            {
                if($row['name'])
                {
                header("Location:http://localhost/project/academics.php");
                echo $row['name'];
                }
                
                else "wrong ";

            }
            }
            else
                echo"fail";
    }
else 
    {
        
        //header("Location:http://localhost/project/student.php");
        echo "<script type='text/javascript'>alert('EmpTy Fields');</script>";
    }
?>
