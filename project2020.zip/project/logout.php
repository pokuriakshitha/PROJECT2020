<?php
session_start();
unset($_SESSION['roll']);
unset($_SESSION['password']);
header("Location:http://localhost/project/home.html");

?>