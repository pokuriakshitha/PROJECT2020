<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://fonts.googleapis.com/css2?family=Fondamento:ital@1&display=swap" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <script src="./css/java.js"></script>
    <style>
      body{
        background-image: url(./images/1.jpg);
        background-repeat: repeat-y;
        background-size: 100%;
      margin: 0;
      }
      .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color:white;
    color: black;
    text-align: center;
  }
  .footer p{
    margin: 10px;
  }
    </style>
</head>
<body>
<div>
    <div id="navbar-main">
       <div id="title"> <div>Sistema Wehbsaiht</div></div>
          <div id="item"><a href="logout.php">&nbsp&nbsplogout</a></div>
       </div>
  </div>
  <div style="display:flex;flex-direction:wrap;justify-content:center;">
    <?php
$pdo_parameters = 'mysql:host=localhost;dbname=project';//SERVER AND DATABASE
$database_user = 'root';//DATABASE USER
$user_password = '';//USER PASSWORD
//COMMAND TO ESTABLISH A CONNECTION
$pdo_connection = new PDO($pdo_parameters, $database_user, $user_password); 
//THIS IS THE QUERY WE WILL RUN TO RETRIEVE THE DATA FROM THE PRODUCTS TABLE 
$sql = 'SELECT * FROM syllabus WHERE id = 6';
?>
<!--HTML TABLE HEADERS-->
<table>
    <tr>
      <th><strong><h1>Course Outline : M.Tech</h1></strong></th>
  </tr>
<?php //LOOP TO SHOW THE ROWS OF THE PRODUCTS TABLE       
foreach ($pdo_connection->query($sql) as $row) { ?>
    <tr>
      <td><?php print $row['coursedetails'] ?></td>
    </tr>
<?php } ?>
</table>
  </div>
 
  <div class="footer" style="display: flex;flex-direction: row;justify-content:space-between;align-items: center;">
    <div style="font-size: smaller;">
      @Copyrights Sistema Wehbsaiht
    </div>
    <div  style="font-size: smaller;display: flex;flex-direction: row;justify-content: center;">
      <p><h4>Designed and Developed by</h4></p>
      <p><h4>ASVS KRISHNA RAJESH</h4></p>
      <p><h4>AKSHITHA POKURI</h4></p>
      <p><h4>V.N.S.LIKHITHA</h4></p>
    </div>
    </div>
</body>
<script>
        var x = screen.width;
    var y = document.getElementById('navbar-toggle');
    var z = document.getElementById('navbar-items');
    if(x > 1200){
        y.style.display = 'none';
    }
    else{
        y.style.display = 'block';
        z.style.display = 'none';
    }

</script>

</html>
