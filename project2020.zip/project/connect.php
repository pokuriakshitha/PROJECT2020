<?php
	$studentname = $_POST['sname'];
	$fathername = $_POST['fname'];
	$mothername = $_POST['mname'];
	$dateofbirth = $_POST['sdob'];
	$gender = $_POST['sg'];
	$parentmobile = $_POST['parphone'];
	$studentmobile = $_POST['sphone'];
	$parentmailid = $_POST['fmail'];
	$studentmailid = $_POST['smail'];

	// Database connection
	$conn = new mysqli('127.0.0.1','root','','project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("INSERT INTO admissions(`studentname`, `fathername`, `mothername`, `dateofbirth`, `gender`, `parentmobile`, `studentmobile`, `parentemailid`, `studentemailid`) 
		VALUES ('$studentname','$fathername','$mothername','$dateofbirth','$gender','$parentmobile' ,'$studentmobile' ,'$parentmailid','$studentmailid')");
		$execval = $stmt->execute();
		echo $execval;
		$stmt->close();
		$conn->close();
		header("Location:http://localhost/project/admissions.php");
	}
?>