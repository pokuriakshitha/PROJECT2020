<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://fonts.googleapis.com/css2?family=Fondamento:ital@1&display=swap" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <script src="./css/java.js"></script>
    <style>
            
        #bba{
            display: none;
        }
        #architecture{
            display: none;
        }
        #biotechnology{
            display: none;
        }
        #bpharmacy{
            display: none;
        }
        #humanities{
            display: none;
        }
        #mtech{
            display: none;
        }
        #msc{
            display: none;
        }
        #a-img{
            border-style: solid ;
            border-color: black;
            box-shadow: 5px 5px rgba(0, 0, 0, 0.6);
        }
        body{
        background-image: url(./images/1.jpg);
        height: 100%;
      margin: 0;
      }
      .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color:white;
    color: black;
    text-align: center;
  }
  .footer p{
    margin: 10px;
  }
  #btn1,#btn2,#btn3,#btn4,#btn5,#btn6,#btn7{
      width: 100%;
      background-color: black;
      color: white;
  }
  #btn1:hover,#btn2:hover,#btn3:hover,#btn4:hover,#btn5:hover,#btn6:hover,#btn7:hover{
    background-color: whitesmoke;
    color: black;
  }

    </style>
</head>
<body>
    <div>
        <div id="navbar-main">
           <div id="title"> <div>Sistema Wehbsaiht</div></div>
            </div>
      </div>
    <div id="portal-title">
      <i><h1 id="pt1">ACADEMICS</h1></i>
    </div>
    <div>
      <div id="academics">
        <table style="width: 20%;;height: 100%;">
            <th style="width: 100%;">
                
                <button id="btn1" value="BBA" onclick="myAcademics(this.id)">BBA</button><br/>
                <button id="btn2" value="B.Arch" onclick="myAcademics(this.id)">B.Arch.</button><br/>
                <button id="btn3" value="Bio-Technology" onclick="myAcademics(this.id)">Biotechnology</button><br/>
                <button id="btn4" value="B-Pharmacy" onclick="myAcademics(this.id)">B-Pharmacy</button><br/>
                <button id="btn5" value="Humanities and Social Sciences" onclick="myAcademics(this.id)">HUMANITIES AND SOCIAL SCIENCES</button><br/>
                <button id="btn6" value="M.Tech." onclick="myAcademics(this.id)">M.Tech.</button></li><br/>
                <button id="btn7" value="M.Sc." onclick="myAcademics(this.id)">MSC</button><br/>
            </th>
        </table>
          <table style="width: 80%;position: relative;">
            <th id="page-forms">
                <div id="bba">
                <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/mas.jpg?raw=true"  HSPACE="50" VSPACE="50" height="200px" id = "a-img"></div> 
                <div >These programs thus expose students to a variety of "core subjects" and generally 
                    allow students to specialize in a specific academic area.See aside,the degree also develops the student's practical,managerial and communication skills&business decision,making capability.
                BBA is a good and promising UG course for any student for your future.Career options after during BBA.
                   Why BBA?
                      Better job oppurtunities can be the prime reason for doing BBA.There exist many sectors in which 
                      the studentsget placed.This presents lucrative career options in the world of Business and corporate management.
                      It gives an edge over other students due to the practical knowledge a students due to the practical knowledge a student gets which is a good way to have the options to great career growth. </font></i></div>
                <div>For syllabus <a href="1.php"> click here</a></div>
                </div>
                <div id="architecture">
                    <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/arch.jpg?raw=true"  HSPACE="50" VSPACE="50" height="200px" id = "a-img"></div>
                    <div  id="academy-info">B-ARCH is an undergraduate degree in the field of architecture.This five-year full-time programme is a blend of theorical and practical knowledge for students to learn the art of knowledge for students to learn the art of planning designing and constructing physical structure of various kinds.From ideating to mapping & overseeing the construction,a qualified architectis involved at every stage of any construction project.
                           Career in architecture is attractive,lecurative,and has lots of potential in terms of development.
                           The architectural degree is designed in such a way so,that it fulfills the eduactional component of professional certifying bodies.</font></i> </div>
                           <div>For syllabus <a href="2.php">click here</a></div>
                </div>
                <div id="biotechnology">
                    <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/bio.jpg?raw=true" HSPACE="50" VSPACE="50"  height="200px" id = "a-img"></div>
                    <div  id="academy-info">Biotechnology is a broad area of biology,involving the use of living systems and organism to develop or make products.
                    Depending on the tools and applications,it often overlaps with related scientific fields,the late 20th and early 21st centuries,
                biotechnology has expanded to pharamaceutical therapies and diagnostic tests.</font></i></div>
                <div>For syllabus <a href="3.php"> click here</a></div>

                </div>
                <div id="bpharmacy">
                    <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/pharma.jpg?raw=true" HSPACE="50" VSPACE="50" height="200px" id = "a-img"></div>
                    <div  id="academy-info">A Bachelor of Pharmacy (abbreviated B Pharm or PharmB or BS Pharm) is an undergraduate academic degree in the field of pharmacy. 
                        In many countries, this degree is a prerequisite for registration to practice as a pharmacist. Since both PharmB and PharmD are prerequisites to license in most western countries they’re considered equivalent.
                         In many western countries, the foreign graduates with BPharm, PharmB or BS Pharm practice similarly as PharmD graduates. It is analogous to MBBS vs.
                          MD where MBBS is foreign equivalent of MD. It is training to understand the properties and impacts of medicines and developing the skills required to counsel patients about their use.
                        B Pharm holders can work in several fields such as being a pharmacist, patient counseling, doing further studies such as master's degree, working in a university as a lecturer, or working as a drug information specialist.</font></i></div>
                        <div>For syllabus  <a href="4.php"> click here</a></div>
                </div>
                <div id="humanities">
                    <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/human.jpg?raw=true" HSPACE="50" VSPACE="50"  height="200px" id = "a-img"></div>
                    <div  id="academy-info">The Humanities and Social Sciences are the study of human behaviour and interaction in social, cultural, environmental, economic and political contexts.
                         The Humanities and Social Sciences have a historical and contemporary focus, from personal to global contexts, and consider challenges for the future.
                         A humanities education stresses a versatile assortment of skills, including creativity, critical thinking, research, problem-solving, and communication.
                          A 2016 survey from the National Association of Colleges and Employers reported that employers commonly rank skills in communication and problem-solving above technical training, indicating the professional value of a liberal arts education.
                           Graduates can pursue a wide variety of careers with a humanities education, including business, media, education, government, and nonprofit work.</font></i></div>
                           <div>For syllabus <a href="5.php"> click here</a></div>
                    </div> 
                <div id="mtech">
                    <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/mtech.jpg?raw=true" HSPACE="50" VSPACE="50" height="200px" id = "a-img"></div>
                    <div  id="academy-info">Post Graduate course Mtech is a 2 year or 4 semester masters degree program.
                         This course are offered whose students they want increase own knowledge and qualification in engineering. In this 2 year degree program students learn advance level and research in any domain of computer science.
                         This course is high demanded course in Information Technology sectors.
                         This course are covering advance level Networking syllabus, update Algorithms, Data Bases, Computer Architecture, Distributed Computing and Computational Intelligence.</font><i></div>
                         <div>For syllabus <a href="6.php">click here</a></div>
                </div>
                <div id="msc">
                    <div><img src="https://github.com/ASVSKR/project/blob/master/IMAGES/mscc.jpg?raw=true" HSPACE="50" VSPACE="50" height="200px" id = "a-img"></div>
                    <div  id="academy-info">A Master of Science can generally be completed either in the classroom or through online study.
    
                        The question of what is an MSc in Chemistry can be answered by understanding how post-graduate science education is structured.
                         Post-graduate education in chemistry is generally pursued by students who have an undergraduate degree in the same field. However, an Msc in Chemistry is often more specialized, allowing students to pursue a specific type or area in the field of chemistry.
                        
                        Many top research and teaching positions require students to have at least an MSc in Chemistry in order to be considered. A Masters degree is also a gateway to all other types of post-graduate work, including a Doctoral degree in the field. 
                        Additionally, postgraduate students in chemistry often have access to equipment and facilities that are not available to those doing undergraduate work.</font></i></div>
                        <div>For syllabus <a href="7.php">click here</a></div>
                    </div>
            </th>
        </table>
       </div>
    </div>
    <div class="footer" style="display: flex;flex-direction: row;justify-content:space-between;align-items: center;">
    <div style="font-size: smaller;">
      @Copyrights Sistema Wehbsaiht
    </div>
    <div  style="font-size: smaller;display: flex;flex-direction: row;justify-content: center;">
      <p><h4>Designed and Developed by</h4></p>
      <p><h4>ASVS KRISHNA RAJESH</h4></p>
      <p><h4>AKSHITHA POKURI</h4></p>
      <p><h4>V.N.S.LIKHITHA</h4></p>
    </div>
    </div>
    inkaa em unaai logout buttin annav endhuloo
</body>
<script>
        var x = screen.width;
    var y = document.getElementById('navbar-toggle');
    var z = document.getElementById('navbar-items');
    if(x > 1200){
        y.style.display = 'none';
    }
    else{
        y.style.display = 'block';
        z.style.display = 'none';
    }

</script>
<script>
    function myAcademics(click){
        var x = click;
            var z = document.getElementById(x).value;
            var y = document.getElementById("engineering");
            var a = document.getElementById("bba");
            var b = document.getElementById("architecture");
            var c = document.getElementById("biotechnology");
            var d = document.getElementById("bpharmacy");
            var e = document.getElementById("humanities");
            var f = document.getElementById("mtech");
            var g = document.getElementById("msc");
            document.getElementById("pt1").innerHTML = z;
            if(x == 'btn'){
                a.style.display = 'none';
                b.style.display = 'none';
                c.style.display = 'none';
                d.style.display = 'none';
                e.style.display = 'none';
                f.style.display = 'none';
                g.style.display = 'none';
                y.style.display = 'block';
            }
            if(x == 'btn1'){
                a.style.display = 'block';
                b.style.display = 'none';
                c.style.display = 'none';
                d.style.display = 'none';
                e.style.display = 'none';
                f.style.display = 'none';
                g.style.display = 'none';
                y.style.display = 'none';
            }
            if(x == 'btn2'){
                a.style.display = 'none';
                b.style.display = 'block';
                c.style.display = 'none';
                d.style.display = 'none';
                e.style.display = 'none';
                f.style.display = 'none';
                g.style.display = 'none';
                y.style.display = 'none';
            }
            if(x == 'btn3'){
                a.style.display = 'none';
                b.style.display = 'none';
                c.style.display = 'block';
                d.style.display = 'none';
                e.style.display = 'none';
                f.style.display = 'none';
                g.style.display = 'none';
                y.style.display = 'none';
            }
            if(x == 'btn4'){
                a.style.display = 'none';
                b.style.display = 'none';
                c.style.display = 'none';
                d.style.display = 'block';
                e.style.display = 'none';
                f.style.display = 'none';
                g.style.display = 'none';
                y.style.display = 'none';
            }
            if(x == 'btn5'){
                a.style.display = 'none';
                b.style.display = 'none';
                c.style.display = 'none';
                d.style.display = 'none';
                e.style.display = 'block';
                f.style.display = 'none';
                g.style.display = 'none';
                y.style.display = 'none';
            }
            if(x == 'btn6'){
                a.style.display = 'none';
                b.style.display = 'none';
                c.style.display = 'none';
                d.style.display = 'none';
                e.style.display = 'none';
                f.style.display = 'block';
                g.style.display = 'none';
                y.style.display = 'none';
            }
            if(x == 'btn7'){
                a.style.display = 'none';
                b.style.display = 'none';
                c.style.display = 'none';
                d.style.display = 'none';
                e.style.display = 'none';
                f.style.display = 'none';
                g.style.display = 'block';
                y.style.display = 'none';
            }
    }
</script>

</html>
